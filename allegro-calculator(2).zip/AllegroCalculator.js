import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectItem } from "@/components/ui/select";

export default function AllegroCalculator() {
  const [price, setPrice] = useState(0);
  const [promotionLevel, setPromotionLevel] = useState("Brak");
  const [smart, setSmart] = useState("Nie");
  const [highlight, setHighlight] = useState("Nie");
  const [result, setResult] = useState(null);

  const commissionRate = 0.0738;
  const highlightCost = 19.9;
  const packagingCost = 1;
  const promotionCosts = { Brak: 0, Lekkie: 5, Mocne: 15, Super: 30 };
  
  const getSmartCost = (price) => {
    if (price >= 200) return 8.69;
    if (price >= 120) return 6.69;
    if (price >= 80) return 3.99;
    if (price >= 60) return 2.89;
    if (price >= 50) return 2.09;
    return 1.59;
  };

  const calculate = () => {
    if (!price || price <= 0) {
      alert("Podaj poprawną cenę produktu.");
      return;
    }

    const commission = price * commissionRate;
    const promotionCost = promotionCosts[promotionLevel] || 0;
    const smartCost = smart === "Tak" ? getSmartCost(price) : 0;
    const highlightCostFinal = highlight === "Tak" ? highlightCost : 0;
    const highlightCommission = highlight === "Tak" ? price * 0.05535 : 0;
    
    const totalCosts = commission + packagingCost + promotionCost + smartCost + highlightCostFinal + highlightCommission;
    const minPrice = price - totalCosts + 5;
    const maxPrice = price - totalCosts + 7;
    
    setResult({ totalCosts, minPrice, maxPrice });
  };

  return (
    <div className="p-6 max-w-md mx-auto">
      <Card>
        <CardContent className="p-4 space-y-4">
          <h2 className="text-xl font-semibold">Kalkulator Allegro</h2>
          <Input type="number" placeholder="Cena produktu" value={price} onChange={(e) => setPrice(parseFloat(e.target.value) || 0)} />
          
          <Select value={promotionLevel} onValueChange={setPromotionLevel}>
            <SelectItem value="Brak">Brak Promowania</SelectItem>
            <SelectItem value="Lekkie">Lekkie Promowanie (5 zł)</SelectItem>
            <SelectItem value="Mocne">Mocne Promowanie (15 zł)</SelectItem>
            <SelectItem value="Super">Super Promowanie (30 zł)</SelectItem>
          </Select>
          
          <Select value={smart} onValueChange={setSmart}>
            <SelectItem value="Nie">Bez Smart!</SelectItem>
            <SelectItem value="Tak">Z Allegro Smart!</SelectItem>
          </Select>
          
          <Select value={highlight} onValueChange={setHighlight}>
            <SelectItem value="Nie">Bez Wyróżnienia</SelectItem>
            <SelectItem value="Tak">Z Wyróżnieniem (19,90 zł)</SelectItem>
          </Select>
          
          <Button onClick={calculate} className="w-full">Oblicz</Button>
          
          {result && (
            <div className="mt-4 p-4 bg-gray-100 rounded-lg">
              <p><strong>Całkowite koszty:</strong> {result.totalCosts.toFixed(2)} zł</p>
              <p><strong>Minimalna cena sprzedaży (5 zł zysku):</strong> {result.minPrice.toFixed(2)} zł</p>
              <p><strong>Maksymalna cena sprzedaży (7 zł zysku):</strong> {result.maxPrice.toFixed(2)} zł</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
